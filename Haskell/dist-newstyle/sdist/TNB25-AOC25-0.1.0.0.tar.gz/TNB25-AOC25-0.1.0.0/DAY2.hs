module DAY2 where

import Data.List.Split (splitOn)
import Text.Regex.PCRE

main :: IO()
main = do
    file <- readFile "../External_Files/ids.txt"
    print ("4444" =~ "^(\\d+)\\1$" :: Bool)
    print $ checkRanges (splitOn "," file)

pattern1, pattern2 :: String
pattern1 = "^(\\d+)\\1$"
pattern2 = "^(\\d+)\\1+$"

checkRanges :: [String] -> (Int,Int)
checkRanges = foldr ((\(x1,y1) (x2,y2) -> (x1+x2,y1+y2)) . checkRange) (0,0)

checkRange :: String -> (Int,Int)
checkRange str = (count pattern1, count pattern2)
  where
    (a,_:b) = break (== '-') str
    range = [(read a :: Int)..(read b :: Int)]
    count pt = length (filter (\x -> show x =~ (pt :: String)) range)

-- with open("/Users/tristanbasri/Desktop/Code/Python_3/dials.txt") as f:
--     ranges = f.read().split(',')
-- f.close()

-- # alternative (easier imo) regex solution
-- pattern1 = re.compile(r'^(\d+)\1$')
-- pattern2 = re.compile(r'^(\d+)\1+$')
-- def find(x):
--     a, b = x
--     a, b = int(a), int(b)
--     s1 = s2 = 0
--     for k in range(a,b+1):
--         if pattern1.match(str(k)): s1 += k
--         if pattern2.match(str(k)): s2 += k
--     return (s1,s2)

-- rs = [find(x.split('-')) for x in ranges]
-- ans = list(map(sum,zip(*rs)))
-- print(ans) # 40214376723 50793864718